layout = {
	['icon_bot_artillery_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_bot_antiair_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_bot_intel_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_bot_engineer_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_bot_directfire_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_bot_generic_over'] = {left = 8, top = 11, width = 16, height = 12, },
}

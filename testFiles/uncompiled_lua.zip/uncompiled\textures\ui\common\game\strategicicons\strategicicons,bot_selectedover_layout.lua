layout = {
	['icon_bot_artillery_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_bot_antiair_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_bot_intel_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_bot_engineer_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_bot_directfire_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_bot_generic_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
}

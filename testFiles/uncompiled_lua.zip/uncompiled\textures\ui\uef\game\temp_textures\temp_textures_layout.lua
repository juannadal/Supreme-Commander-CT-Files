layout = {
	['checkmark_dark'] = {left = 1, top = 2, width = 19, height = 18, },
	['checkmark'] = {left = 1, top = 2, width = 19, height = 18, },
	['combo_sel'] = {left = 4, top = 2, width = 14, height = 16, },
	['combo_up'] = {left = 4, top = 2, width = 14, height = 16, },
}

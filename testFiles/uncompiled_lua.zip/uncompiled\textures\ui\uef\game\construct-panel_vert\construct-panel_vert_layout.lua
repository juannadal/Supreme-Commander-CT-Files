layout = {
	['que-panel_bmp_t'] = {left = 21, top = 71, width = 60, height = 8, leftOffset = 1, topOffset = 0, },
	['que-panel_bmp_m'] = {left = 21, top = 79, width = 60, height = 8, leftOffset = 1, topOffset = 0, },
	['que-panel_bmp_b'] = {left = 21, top = 180, width = 60, height = 8, leftOffset = 1, topOffset = 0, },
	['construct-panel_bmp_t'] = {left = 10, top = 9, width = 172, height = 64, leftOffset = 0, topOffset = 1, },
	['construct-panel_bmp_m'] = {left = 10, top = 79, width = 172, height = 8, leftOffset = 0, topOffset = 0, },
	['construct-panel_bmp_b'] = {left = 10, top = 288, width = 172, height = 12, leftOffset = 0, topOffset = 0, },
}

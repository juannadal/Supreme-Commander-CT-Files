layout = {
	['icon_ship_missile_over'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_counterintel_over'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_shield_over'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_antinavy_over'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_antiair_over'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_air_over'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_directfire_over'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_intel_over'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_generic_over'] = {left = 9, top = 10, width = 16, height = 12, },
}

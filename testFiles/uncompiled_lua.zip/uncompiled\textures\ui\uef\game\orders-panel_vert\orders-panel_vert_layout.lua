layout = {
	['l_orders'] = {left = 32, top = 18, width = 188, height = 94, leftOffset = 0, topOffset = 0, },
	['bracket_bmp'] = {left = 1, top = 7, width = 36, height = 224, leftOffset = 0, topOffset = 1, },
	['order-panel_bmp'] = {left = 18, top = 6, width = 188, height = 224, leftOffset = 1, topOffset = 0, },
}

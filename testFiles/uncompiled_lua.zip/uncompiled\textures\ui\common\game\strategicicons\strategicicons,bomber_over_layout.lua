layout = {
	['icon_bomber_antinavy_over'] = {left = 7, top = 10, width = 20, height = 12, },
	['icon_bomber_directfire_over'] = {left = 7, top = 10, width = 20, height = 12, },
	['icon_bomber_generic_over'] = {left = 7, top = 10, width = 20, height = 12, },
}

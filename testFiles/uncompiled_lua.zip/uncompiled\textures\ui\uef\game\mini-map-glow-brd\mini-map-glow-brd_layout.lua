layout = {
	['mini-map-glow_brd_lr'] = {left = 167, top = 165, width = 40, height = 40, },
	['mini-map-glow_brd_lm'] = {left = 40, top = 181, width = 8, height = 24, },
	['mini-map-glow_brd_ll'] = {left = 1, top = 165, width = 40, height = 40, },
	['mini-map-glow_brd_vert_r'] = {left = 182, top = 40, width = 24, height = 8, },
	['mini-map-glow_brd_vert_l'] = {left = 2, top = 40, width = 24, height = 8, },
	['mini-map-glow_brd_ur'] = {left = 167, top = 1, width = 40, height = 40, },
	['mini-map-glow_brd_horz_um'] = {left = 40, top = 1, width = 8, height = 24, },
	['mini-map-glow_brd_ul'] = {left = 1, top = 1, width = 40, height = 40, },
}

layout = {
	['radio_btn_down'] = {left = 1, top = 0, width = 27, height = 28, },
	['radio_btn_over'] = {left = 1, top = 0, width = 27, height = 28, },
	['radio_btn_up'] = {left = 1, top = 0, width = 27, height = 28, },
	['radio_btn_dis'] = {left = 1, top = 0, width = 27, height = 28, },
}

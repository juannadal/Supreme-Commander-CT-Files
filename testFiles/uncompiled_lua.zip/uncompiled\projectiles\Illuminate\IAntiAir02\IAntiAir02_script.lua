-----------------------------------------------------------------------------
--  File     :  /projectiles/illuminate/iantiair02/iantiair02_script.lua
--  Author(s):
--  Summary  :  SC2 Illuminate AntiAir: IAntiAir02
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

IAntiAir02 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = IAntiAir02
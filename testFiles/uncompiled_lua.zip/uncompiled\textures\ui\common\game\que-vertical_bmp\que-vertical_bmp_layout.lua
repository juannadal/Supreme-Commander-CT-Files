layout = {
	['l_infinity_button'] = {left = 17, top = 41, width = 35, height = 27, },
	['l_right_scroll'] = {left = 37, top = 13, width = 21, height = 22, },
	['l_left_scroll'] = {left = 13, top = 13, width = 21, height = 22, },
	['scroll-back_bmp'] = {left = 7, top = 10, width = 60, height = 28, },
	['que-02_bmp_t'] = {left = 5, top = 1, width = 236, height = 16, },
	['que-02_bmp_m'] = {left = 5, top = 17, width = 236, height = 16, },
	['que-02_bmp_b'] = {left = 5, top = 62, width = 236, height = 16, },
	['que_bmp_t'] = {left = 5, top = 1, width = 236, height = 16, },
	['que_bmp_m'] = {left = 5, top = 17, width = 236, height = 16, },
	['que_bmp_b'] = {left = 5, top = 62, width = 236, height = 16, },
}

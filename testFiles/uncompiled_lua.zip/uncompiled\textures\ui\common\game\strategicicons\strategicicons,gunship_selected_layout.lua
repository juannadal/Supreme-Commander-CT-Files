layout = {
	['icon_gunship_antiair_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_gunship_transport_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_gunship_directfire_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_gunship_generic_selected'] = {left = 6, top = 9, width = 20, height = 16, },
}

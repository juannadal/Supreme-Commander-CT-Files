-----------------------------------------------------------------------------
--  File     :  /units/scenario/scb0004/scb0004_script.lua
--  Author(s):	Chris Daroza
--  Summary  :  SC2 Illuminate Warehouse 01: SCB0004
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

local StructureUnit = import('/lua/sim/StructureUnit.lua').StructureUnit

SCB0004 = Class(StructureUnit) {
}
TypeClass = SCB0004
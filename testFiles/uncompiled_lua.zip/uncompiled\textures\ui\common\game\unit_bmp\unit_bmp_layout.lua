layout = {
	['veteran-logo_bmp'] = {left = 136, top = 12, width = 16, height = 16, },
	['bar02_bmp'] = {left = 8, top = 144, width = 148, height = 8, },
	['bar-01_bmp'] = {left = 8, top = 138, width = 148, height = 8, },
	['bar-info-back_bmp'] = {left = 4, top = 156, width = 152, height = 12, },
	['unit-over_bmp'] = {left = 0, top = 2, width = 160, height = 220, },
}

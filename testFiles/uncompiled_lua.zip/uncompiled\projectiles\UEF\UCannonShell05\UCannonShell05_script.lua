-----------------------------------------------------------------------------
--  File     : /projectiles/UEF/UCannonShell05/UCannonShell05_script.lua
--  Author(s): Aaron Lundquist
--  Summary  : SC2 UEF Generic Cannon Shell: UCannonShell05
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
UCannonShell05 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = UCannonShell05
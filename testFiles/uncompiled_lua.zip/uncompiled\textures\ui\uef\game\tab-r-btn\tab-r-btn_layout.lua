layout = {
	['tab-close_btn_down'] = {left = 1, top = 0, width = 18, height = 28, },
	['tab-close_btn_over'] = {left = 0, top = 0, width = 20, height = 28, },
	['tab-close_btn_up'] = {left = 0, top = 0, width = 20, height = 28, },
	['tab-close_btn_dis'] = {left = 0, top = 0, width = 20, height = 28, },
	['tab-open_btn_down'] = {left = 1, top = 0, width = 18, height = 28, },
	['tab-open_btn_over'] = {left = 0, top = 0, width = 20, height = 28, },
	['tab-open_btn_up'] = {left = 0, top = 0, width = 20, height = 28, },
	['tab-open_btn_dis'] = {left = 0, top = 0, width = 20, height = 28, },
}

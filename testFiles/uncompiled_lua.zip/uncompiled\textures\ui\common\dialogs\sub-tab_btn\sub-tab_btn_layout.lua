layout = {
	['sub-tab_btn_selected'] = {left = 1, top = 0, width = 119, height = 24, },
	['sub-tab_btn_down'] = {left = 1, top = 0, width = 119, height = 24, },
	['sub-tab_btn_over'] = {left = 1, top = 0, width = 119, height = 24, },
	['sub-tab_btn_up'] = {left = 1, top = 0, width = 119, height = 24, },
	['sub-tab_btn_dis'] = {left = 1, top = 0, width = 119, height = 24, },
}

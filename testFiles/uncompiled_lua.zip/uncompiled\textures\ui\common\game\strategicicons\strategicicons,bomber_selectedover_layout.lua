layout = {
	['icon_bomber_antinavy_selectedover'] = {left = 5, top = 8, width = 24, height = 16, },
	['icon_bomber_directfire_selectedover'] = {left = 5, top = 8, width = 24, height = 16, },
	['icon_bomber_generic_selectedover'] = {left = 5, top = 8, width = 24, height = 16, },
}

layout = {
	['bracket-build_bmp'] = {left = 0, top = 0, width = 344, height = 132, leftOffset = 1, topOffset = 1, },
	['fuelbar'] = {left = 79, top = 52, width = 188, height = 4, leftOffset = 0, topOffset = 0, },
	['shieldbar'] = {left = 79, top = 48, width = 188, height = 4, leftOffset = 0, topOffset = 0, },
	['healthbar_green'] = {left = 78, top = 35, width = 192, height = 24, leftOffset = 1, topOffset = 1, },
	['healthbar_yellow'] = {left = 78, top = 35, width = 192, height = 24, leftOffset = 1, topOffset = 1, },
	['healthbar_red'] = {left = 78, top = 35, width = 192, height = 24, leftOffset = 1, topOffset = 1, },
	['healthbar_bg'] = {left = 79, top = 36, width = 188, height = 20, leftOffset = 0, topOffset = 0, },
	['build-over-back_bmp'] = {left = 11, top = 2, width = 332, height = 116, leftOffset = 0, topOffset = 1, },
	['bracket-unit_bmp'] = {left = 0, top = 0, width = 344, height = 116, leftOffset = 1, topOffset = 1, },
	['unit-over-back_bmp'] = {left = 11, top = 2, width = 332, height = 116, leftOffset = 0, topOffset = 1, },
}

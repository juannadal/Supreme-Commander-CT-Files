-----------------------------------------------------------------------------
--  File     :  /Units/Scenario/SCB0014/SCB0014_script.lua
--  Author(s):	Chris Daroza
--  Summary  :  SC2 Generic Building 04: SCB0014
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

local StructureUnit = import('/lua/sim/StructureUnit.lua').StructureUnit

SCB0014 = Class(StructureUnit) {
}
TypeClass = SCB0014
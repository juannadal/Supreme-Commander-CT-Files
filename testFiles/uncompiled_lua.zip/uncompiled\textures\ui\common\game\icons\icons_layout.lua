layout = {
	['icon-trash-lg_btn_down'] = {left = 6, top = 0, width = 56, height = 64, },
	['icon-trash-lg_btn_over'] = {left = 6, top = 0, width = 56, height = 64, },
	['icon-trash-lg_btn_up'] = {left = 9, top = 0, width = 52, height = 64, },
	['icon-trash-lg_btn_dis'] = {left = 13, top = 4, width = 44, height = 56, },
	['icon-trash_btn_down'] = {left = 25, top = 26, width = 16, height = 16, },
	['icon-trash_btn_over'] = {left = 23, top = 20, width = 20, height = 24, },
	['icon-trash_btn_up'] = {left = 23, top = 24, width = 20, height = 20, },
	['icon-trash_btn_dis'] = {left = 27, top = 28, width = 12, height = 12, },
}

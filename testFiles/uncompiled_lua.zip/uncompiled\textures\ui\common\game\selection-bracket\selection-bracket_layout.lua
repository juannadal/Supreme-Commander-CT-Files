layout = {
	['selection_brackets_neutral_highlighted'] = {left = 0, top = 0, width = 128, height = 128, },
	['selection_brackets_neutral'] = {left = 0, top = 0, width = 128, height = 128, },
	['selection_brackets_enemy_highlighted'] = {left = 0, top = 0, width = 128, height = 128, },
	['selection_brackets_enemy'] = {left = 0, top = 0, width = 128, height = 128, },
	['selection_brackets_player_highlighted'] = {left = 0, top = 0, width = 128, height = 128, },
	['selection_brackets_player'] = {left = 0, top = 0, width = 128, height = 128, },
}

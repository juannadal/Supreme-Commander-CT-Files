layout = {
	['l_title-text'] = {left = 13, top = 16, width = 117, height = 11, },
	['l_drop-box_btn_up'] = {left = 129, top = 9, width = 28, height = 24, },
	['l_pause_btn_up'] = {left = 56, top = 71, width = 51, height = 44, },
	['l_slider'] = {left = 24, top = 178, width = 103, height = 19, },
	['l_10'] = {left = 134, top = 184, width = 19, height = 9, },
	['l_0'] = {left = 11, top = 184, width = 5, height = 9, },
	['l_game-speed-text'] = {left = 45, top = 164, width = 71, height = 11, },
	['game-speed-bmp'] = {left = 22, top = 180, width = 116, height = 20, },
	['slider-ticks_bmp'] = {left = 29, top = 195, width = 104, height = 8, },
	['panel_bmp'] = {left = 0, top = 1, width = 160, height = 220, },
}

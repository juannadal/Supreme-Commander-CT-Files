-----------------------------------------------------------------------------
--  File     : /projectiles/UEF/UCannonShell03/UCannonShell03_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 UEF Fatboy Cannon Shell: UCannonShell03
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
UCannonShell03 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = UCannonShell03
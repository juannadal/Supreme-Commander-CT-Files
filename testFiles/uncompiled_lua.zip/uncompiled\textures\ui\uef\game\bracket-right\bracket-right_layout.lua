layout = {
	['bracket_bmp_t'] = {left = 2, top = 6, width = 32, height = 68, },
	['bracket_bmp_m'] = {left = 11, top = 86, width = 16, height = 4, },
	['bracket_bmp_b'] = {left = 2, top = 98, width = 32, height = 28, },
	['bracket_bmp'] = {left = 2, top = 6, width = 32, height = 120, },
}

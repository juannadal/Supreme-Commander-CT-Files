layout = {
	['arrow-left_scr_down'] = {left = 0, top = 0, width = 24, height = 48, },
	['arrow-left_scr_over'] = {left = 0, top = 0, width = 24, height = 48, },
	['arrow-left_scr_up'] = {left = 0, top = 0, width = 24, height = 48, },
	['arrow-left_scr_dis'] = {left = 0, top = 0, width = 24, height = 48, },
	['arrow-right_scr_down'] = {left = 0, top = 0, width = 24, height = 48, },
	['arrow-right_scr_over'] = {left = 0, top = 0, width = 24, height = 48, },
	['arrow-right_scr_up'] = {left = 0, top = 0, width = 24, height = 48, },
	['arrow-right_scr_dis'] = {left = 0, top = 0, width = 24, height = 48, },
}

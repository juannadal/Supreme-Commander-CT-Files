layout = {
	['beacon-quantum-gate_btn_up'] = {left = 0, top = 0, width = 128, height = 128, },
	['beacon-aeon-transport_btn_up'] = {left = 0, top = 0, width = 128, height = 128, },
}

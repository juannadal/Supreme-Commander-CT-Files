-----------------------------------------------------------------------------
--  File     :  /Units/Scenario/SCB0022/SCB0022_script.lua
--  Author(s):	Chris Daroza
--  Summary  :  SC2 Derelict Generic Building 02: SCB0022
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

local StructureUnit = import('/lua/sim/StructureUnit.lua').StructureUnit

SCB0022 = Class(StructureUnit) {
}
TypeClass = SCB0022
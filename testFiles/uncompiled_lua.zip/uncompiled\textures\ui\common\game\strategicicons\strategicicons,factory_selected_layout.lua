layout = {
	['icon_factory_air_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_factory_land_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_factory_naval_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_factory_generic_selected'] = {left = 6, top = 9, width = 20, height = 16, },
}

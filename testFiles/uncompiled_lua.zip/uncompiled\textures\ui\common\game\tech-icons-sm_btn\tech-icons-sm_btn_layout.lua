layout = {
	['upgrade-icon_btn_down'] = {left = 0, top = 0, width = 32, height = 32, },
	['upgrade-icon_btn_over'] = {left = 0, top = 0, width = 32, height = 32, },
	['upgrade-icon_btn_up'] = {left = 0, top = 0, width = 32, height = 32, },
	['upgrade-icon_btn_dis'] = {left = 5, top = 4, width = 22, height = 24, },
}

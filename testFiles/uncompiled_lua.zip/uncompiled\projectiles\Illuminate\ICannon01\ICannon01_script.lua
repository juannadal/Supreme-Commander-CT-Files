-----------------------------------------------------------------------------
--  File     : /projectiles/Illuminate/ICannon01/ICannon01_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 Illuminate Assualt Bot Cannon: ICannon01
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
ICannon01 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = ICannon01
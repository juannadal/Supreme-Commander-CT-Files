-----------------------------------------------------------------------------
--  File     : /projectiles/uef/uantitacticalmissile01/uantitacticalmissile01_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 UEF Anti-Tactical Missile: UTAntiTacticalMissile01
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
local Projectile = import('/lua/sim/Projectile.lua').Projectile

UTacticalMissile01 = Class(Projectile) {
}
TypeClass = UTacticalMissile01
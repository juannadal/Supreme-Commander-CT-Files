-----------------------------------------------------------------------------
--  File     : /projectiles/illuminate/iartillery01/iartillery01_script.lua
--  Author(s): Gordon Duclos, Aaron Lundquist
--  Summary  : SC2 Illuminate Urchinow Artillery: IArtillery01
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
IArtillery01 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = IArtillery01
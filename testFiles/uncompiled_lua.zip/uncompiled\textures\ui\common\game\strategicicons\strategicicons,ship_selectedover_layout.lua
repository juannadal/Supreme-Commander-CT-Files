layout = {
	['icon_ship_missile_selectedover'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_counterintel_selectedover'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_shield_selectedover'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_antinavy_selectedover'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_antiair_selectedover'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_air_selectedover'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_directfire_selectedover'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_intel_selectedover'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_generic_selectedover'] = {left = 7, top = 8, width = 20, height = 16, },
}

layout = {
	['l_tab'] = {left = 19, top = 29, width = 12, height = 22, leftOffset = 0, topOffset = 0, },
	['l_pings'] = {left = 49, top = 14, width = 139, height = 27, leftOffset = 0, topOffset = 0, },
	['l_filters'] = {left = 38, top = 14, width = 136, height = 53, leftOffset = 0, topOffset = 0, },
	['bracket-energy-r_bmp'] = {left = 194, top = 6, width = 20, height = 72, leftOffset = 0, topOffset = 1, },
	['bracket-left_bmp'] = {left = 17, top = 6, width = 28, height = 68, leftOffset = 1, topOffset = 0, },
	['bracket-energy-l_bmp'] = {left = 28, top = 6, width = 20, height = 72, leftOffset = 0, topOffset = 1, },
	['filter-ping-panel02_bmp'] = {left = 28, top = 6, width = 180, height = 72, leftOffset = 0, topOffset = 1, },
}

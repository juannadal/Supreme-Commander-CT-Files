layout = {
	['tech-level_open'] = {left = 2, top = 2, width = 4, height = 4, },
	['tech-level_solid'] = {left = 2, top = 2, width = 4, height = 4, },
}

layout = {
	['icon_factory_air_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_factory_land_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_factory_naval_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_factory_generic_over'] = {left = 8, top = 11, width = 16, height = 12, },
}

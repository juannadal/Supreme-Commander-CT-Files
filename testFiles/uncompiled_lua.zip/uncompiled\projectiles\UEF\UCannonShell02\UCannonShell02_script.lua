-----------------------------------------------------------------------------
--  File     : /projectiles/UEF/UCannonShell02/UCannonShell02_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 UEF Fatboy Cannon Shell: UCannonShell02
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
UCannonShell02 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = UCannonShell02
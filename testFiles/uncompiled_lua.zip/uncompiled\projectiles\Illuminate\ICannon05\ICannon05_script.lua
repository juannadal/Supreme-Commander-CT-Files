-----------------------------------------------------------------------------
--  File     : /projectiles/Illuminate/ICannon05/ICannon05_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 Illuminate Gunship Ground Cannon: ICannon05
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
ICannon05 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = ICannon05
layout = {
	['l_text'] = {left = 93, top = 71, width = 56, height = 14, },
	['l_btns'] = {left = 215, top = 69, width = 53, height = 15, },
	['mini-map-glow_bmp'] = {left = 75, top = 82, width = 208, height = 208, },
	['mini-map_brd_lr'] = {left = 271, top = 277, width = 16, height = 16, },
	['mini-map_brd_lm'] = {left = 112, top = 277, width = 12, height = 16, },
	['mini-map_brd_ll'] = {left = 73, top = 277, width = 12, height = 16, },
	['mini-map_brd_vert_r'] = {left = 271, top = 101, width = 16, height = 12, },
	['mini-map_brd_m'] = {left = 112, top = 101, width = 12, height = 12, },
	['mini-map_brd_vert_l'] = {left = 73, top = 101, width = 12, height = 12, },
	['mini-map_brd_ur'] = {left = 251, top = 61, width = 36, height = 36, },
	['mini-map_brd_horz_um'] = {left = 112, top = 61, width = 12, height = 36, },
	['mini-map_brd_ul'] = {left = 73, top = 61, width = 32, height = 36, },
}

layout = {
	['bg-right'] = {left = 95, top = 8, width = 24, height = 36, },
	['bg-stretch'] = {left = 32, top = 8, width = 8, height = 36, },
	['bg-mid'] = {left = 49, top = 5, width = 32, height = 40, },
	['bg-left'] = {left = 10, top = 8, width = 24, height = 36, },
}

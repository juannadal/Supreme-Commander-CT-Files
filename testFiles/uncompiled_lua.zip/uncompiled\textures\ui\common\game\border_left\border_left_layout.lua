layout = {
	['back_brd_br'] = {left = 972, top = 716, width = 48, height = 48, },
	['back_brd_b-os'] = {left = 616, top = 757, width = 4, height = 8, },
	['back_brd_bl'] = {left = 243, top = 716, width = 48, height = 48, },
	['back_brd_r-os'] = {left = 1012, top = 381, width = 8, height = 4, },
	['back_brd_l-os'] = {left = 243, top = 381, width = 8, height = 4, },
	['back_brd_tr'] = {left = 972, top = 44, width = 48, height = 48, },
	['back_brd_t-os'] = {left = 616, top = 44, width = 4, height = 8, },
	['back_brd_tl'] = {left = 243, top = 44, width = 48, height = 48, },
	['back_brd_b'] = {left = 616, top = 764, width = 4, height = 4, },
	['back_brd_r'] = {left = 1020, top = 381, width = 4, height = 4, },
	['back_brd_l'] = {left = 0, top = 381, width = 244, height = 4, },
	['back_brd_t'] = {left = 616, top = 0, width = 4, height = 44, },
}

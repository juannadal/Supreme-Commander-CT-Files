layout = {
	['l_cancel_btn copy 2'] = {left = 219, top = 40, width = 98, height = 30, },
	['l_standard_btn_up copy 2'] = {left = 127, top = 40, width = 98, height = 30, },
	['l_text-etc'] = {left = 25, top = 19, width = 113, height = 21, },
	['unit-name_bmp'] = {left = 0, top = 0, width = 340, height = 88, },
}

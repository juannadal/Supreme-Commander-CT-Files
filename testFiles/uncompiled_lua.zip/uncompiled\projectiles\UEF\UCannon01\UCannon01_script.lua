-----------------------------------------------------------------------------
--  File     : /projectiles/UEF/UCannon01/UCannon01_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 UEF Commander Cannon Shell: UCannon01
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
UCannon01 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = UCannon01
layout = {
	['back_brd_bl'] = {left = 4, top = 716, width = 48, height = 48, },
	['back_brd_b-os'] = {left = 404, top = 757, width = 4, height = 8, },
	['back_brd_br'] = {left = 733, top = 716, width = 48, height = 48, },
	['back_brd_l-os'] = {left = 4, top = 381, width = 8, height = 4, },
	['back_brd_r-os'] = {left = 773, top = 381, width = 8, height = 4, },
	['back_brd_tl'] = {left = 4, top = 44, width = 48, height = 48, },
	['back_brd_t-os'] = {left = 404, top = 44, width = 4, height = 8, },
	['back_brd_tr'] = {left = 733, top = 44, width = 48, height = 48, },
	['back_brd_b'] = {left = 404, top = 764, width = 4, height = 4, },
	['back_brd_l'] = {left = 0, top = 381, width = 4, height = 4, },
	['back_brd_r'] = {left = 781, top = 381, width = 244, height = 4, },
	['back_brd_t'] = {left = 404, top = 0, width = 4, height = 44, },
}

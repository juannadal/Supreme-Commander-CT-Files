layout = {
	['que-panel_bmp_r'] = {left = 189, top = 88, width = 12, height = 52, leftOffset = 0, topOffset = 1, },
	['que-panel_bmp_m'] = {left = 89, top = 88, width = 8, height = 52, leftOffset = 0, topOffset = 1, },
	['que-panel_bmp_l'] = {left = 77, top = 88, width = 12, height = 52, leftOffset = 0, topOffset = 1, },
	['construct-panel_s_bmp_r'] = {left = 316, top = 32, width = 16, height = 112, leftOffset = 0, topOffset = 1, },
	['construct-panel_s_bmp_m'] = {left = 89, top = 32, width = 8, height = 112, leftOffset = 0, topOffset = 1, },
	['construct-panel_s_bmp_l'] = {left = 8, top = 32, width = 16, height = 112, leftOffset = 0, topOffset = 1, },
	['construct-panel_bmp_r'] = {left = 316, top = 32, width = 16, height = 112, leftOffset = 0, topOffset = 1, },
	['construct-panel_bmp_m3'] = {left = 308, top = 32, width = 8, height = 112, leftOffset = 0, topOffset = 1, },
	['construct-panel_bmp_m2'] = {left = 201, top = 6, width = 16, height = 136, leftOffset = 0, topOffset = 0, },
	['construct-panel_bmp_m1'] = {left = 89, top = 6, width = 8, height = 136, leftOffset = 0, topOffset = 0, },
	['construct-panel_bmp_l'] = {left = 8, top = 6, width = 84, height = 136, leftOffset = 1, topOffset = 0, },
}

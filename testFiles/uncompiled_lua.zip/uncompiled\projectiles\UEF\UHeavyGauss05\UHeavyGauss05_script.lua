-----------------------------------------------------------------------------
--  File     :  /projectiles/uef/uheavygauss05/uheavygauss05_script.lua
--  Author(s):
--  Summary  :  SC2 UEF Heavy Gauss: UHeavyGauss05
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
local Projectile = import('/lua/sim/Projectile.lua').Projectile

UHeavyGauss05 = Class(Projectile) {
}
TypeClass = UHeavyGauss05

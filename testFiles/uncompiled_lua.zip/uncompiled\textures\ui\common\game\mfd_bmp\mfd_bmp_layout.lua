layout = {
	['l_mfd_left_btn_4'] = {left = 11, top = 133, width = 51, height = 39, },
	['l_mfd_left_btn_3'] = {left = 11, top = 93, width = 51, height = 39, },
	['l_mfd_left_btn_2'] = {left = 11, top = 53, width = 51, height = 39, },
	['l_mfd_left_btn_1'] = {left = 11, top = 14, width = 51, height = 39, },
	['l_mfd_left_btn_5'] = {left = 11, top = 172, width = 51, height = 39, },
	['mfd_glow'] = {left = 61, top = 0, width = 224, height = 220, },
	['mfd_button_bmp'] = {left = 3, top = 1, width = 68, height = 220, },
	['mfd_bmp'] = {left = 63, top = 1, width = 220, height = 220, },
}

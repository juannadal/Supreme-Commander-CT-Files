-----------------------------------------------------------------------------
--  File     : /projectiles/Cybran/CNanobotSplit01/CNanobotSplit01_Script.lua
--  Author(s): Aaron Lundquist
--  Summary  : SC2 Cybran Nanobot Weapon: CNanobotSplit01
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
CNanobotSplit01 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = CNanobotSplit01
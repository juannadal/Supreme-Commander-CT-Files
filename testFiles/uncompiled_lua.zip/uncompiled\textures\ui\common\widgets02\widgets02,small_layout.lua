layout = {
	['small_btn_down'] = {left = 0, top = 0, width = 148, height = 35, },
	['small_btn_over'] = {left = 0, top = 0, width = 148, height = 35, },
	['small_btn_up'] = {left = 0, top = 0, width = 148, height = 35, },
	['small_btn_dis'] = {left = 0, top = 0, width = 148, height = 35, },
}

layout = {
	['glow_bmp'] = {left = 2, top = 2, width = 52, height = 46, },
	['play_btn_down'] = {left = 6, top = 6, width = 43, height = 37, },
	['play_btn_over'] = {left = 7, top = 7, width = 42, height = 36, },
	['play_btn_up'] = {left = 7, top = 7, width = 42, height = 36, },
	['play_btn_dis'] = {left = 7, top = 7, width = 42, height = 36, },
	['pause_btn_down'] = {left = 6, top = 6, width = 43, height = 37, },
	['pause_btn_over'] = {left = 7, top = 7, width = 42, height = 36, },
	['pause_btn_up'] = {left = 7, top = 7, width = 42, height = 36, },
	['pause_btn_dis'] = {left = 7, top = 7, width = 42, height = 36, },
}

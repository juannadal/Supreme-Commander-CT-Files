layout = {
	['l_title-text'] = {left = 16, top = 16, width = 117, height = 11, },
	['l_drop-box_btn_up'] = {left = 132, top = 10, width = 28, height = 23, },
	['l_pause_btn_up'] = {left = 61, top = 74, width = 51, height = 44, },
	['l_slider'] = {left = 183, top = 50, width = 19, height = 103, },
	['l_10'] = {left = 162, top = 42, width = 19, height = 9, },
	['l_0'] = {left = 173, top = 142, width = 5, height = 9, },
	['l_game-speed-text'] = {left = 167, top = 5, width = 34, height = 30, },
	['game-speed-bmp'] = {left = 185, top = 39, width = 20, height = 116, },
	['slider-ticks_bmp'] = {left = 200, top = 45, width = 8, height = 104, },
	['panel_bmp'] = {left = -1, top = 0, width = 220, height = 160, },
}

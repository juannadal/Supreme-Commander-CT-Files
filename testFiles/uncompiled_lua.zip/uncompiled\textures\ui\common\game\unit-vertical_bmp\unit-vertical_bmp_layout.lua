layout = {
	['veteran-logo_bmp'] = {left = 142, top = 10, width = 16, height = 16, },
	['bar02_bmp'] = {left = 13, top = 144, width = 148, height = 8, },
	['bar-01_bmp'] = {left = 13, top = 138, width = 148, height = 8, },
	['bar-back_bmp'] = {left = 13, top = 138, width = 148, height = 8, },
	['bar-info-back02_bmp'] = {left = 162, top = 83, width = 72, height = 36, },
	['bar-info-back01_bmp'] = {left = 162, top = 14, width = 72, height = 24, },
	['unit-over-vertical_bmp'] = {left = 0, top = 0, width = 244, height = 168, },
}

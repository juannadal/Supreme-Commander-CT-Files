-----------------------------------------------------------------------------
--  File     :  /units/scenario/scb0002/scb0002_script.lua
--  Author(s):	Chris Daroza
--  Summary  :  SC2 Coalition Warehouse 02: SCB0002
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

local StructureUnit = import('/lua/sim/StructureUnit.lua').StructureUnit

SCB0002 = Class(StructureUnit) {
}
TypeClass = SCB0002
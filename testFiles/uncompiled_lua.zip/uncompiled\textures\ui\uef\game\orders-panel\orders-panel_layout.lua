layout = {
	['l_orders'] = {left = 32, top = 16, width = 297, height = 96, leftOffset = 0, topOffset = 0, },
	['question-mark_bmp'] = {left = 311, top = 22, width = 16, height = 24, leftOffset = 1, topOffset = 1, },
	['no-parking_bmp'] = {left = 227, top = 15, width = 56, height = 56, leftOffset = 1, topOffset = 1, },
	['bracket_bmp'] = {left = 6, top = 7, width = 32, height = 120, leftOffset = 1, topOffset = 1, },
	['order-panel_bmp'] = {left = 18, top = 6, width = 332, height = 120, leftOffset = 1, topOffset = 0, },
}

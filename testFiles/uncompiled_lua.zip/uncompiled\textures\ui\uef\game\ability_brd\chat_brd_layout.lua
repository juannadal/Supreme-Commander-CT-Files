layout = {
	['chat_brd_lr'] = {left = 0, top = 0, width = 15, height = 14, },
	['chat_brd_lm'] = {left = 0, top = 0, width = 20, height = 14, },
	['chat_brd_ll'] = {left = 5, top = 0, width = 15, height = 14, },
	['chat_brd_vert_r'] = {left = 0, top = 0, width = 15, height = 20, },
	['chat_brd_m'] = {left = 0, top = 0, width = 20, height = 20, },
	['chat_brd_vert_l'] = {left = 5, top = 0, width = 15, height = 20, },
	['chat_brd_ur'] = {left = 0, top = 5, width = 15, height = 15, },
	['chat_brd_horz_um'] = {left = 0, top = 5, width = 20, height = 15, },
	['chat_brd_ul'] = {left = 5, top = 5, width = 15, height = 15, },
}

layout = {
	['bracket_bmp_t'] = {left = 12, top = 8, width = 20, height = 20, leftOffset = 1, topOffset = 0, },
	['bracket_bmp_m'] = {left = 12, top = 42, width = 12, height = 4, leftOffset = 1, topOffset = 0, },
	['bracket_bmp_b'] = {left = 12, top = 60, width = 20, height = 16, leftOffset = 1, topOffset = 0, },
	['bracket_bmp'] = {left = 12, top = 8, width = 20, height = 68, leftOffset = 1, topOffset = 0, },
}

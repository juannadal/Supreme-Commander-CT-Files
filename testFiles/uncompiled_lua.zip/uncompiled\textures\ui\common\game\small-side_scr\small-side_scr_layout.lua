layout = {
	['arrow-left_scr_down'] = {left = 1, top = 0, width = 34, height = 36, },
	['arrow-left_scr_over'] = {left = 0, top = 0, width = 34, height = 36, },
	['arrow-left_scr_up'] = {left = 1, top = 0, width = 33, height = 36, },
	['arrow-left_scr_dis'] = {left = 1, top = 0, width = 33, height = 36, },
	['arrow-right_scr_down'] = {left = 0, top = 0, width = 34, height = 36, },
	['arrow-right_scr_over'] = {left = 0, top = 0, width = 35, height = 36, },
	['arrow-right_scr_up'] = {left = 0, top = 0, width = 33, height = 36, },
	['arrow-right_scr_dis'] = {left = 0, top = 0, width = 33, height = 36, },
}

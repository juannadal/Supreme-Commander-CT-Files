layout = {
	['icon_gunship_antiair_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_gunship_transport_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_gunship_directfire_over'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_gunship_generic_over'] = {left = 8, top = 11, width = 16, height = 12, },
}

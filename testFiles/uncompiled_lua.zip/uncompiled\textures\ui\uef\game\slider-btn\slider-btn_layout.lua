layout = {
	['slider-mass_btn_down'] = {left = 0, top = 0, width = 28, height = 28, },
	['slider-mass_btn_over'] = {left = 4, top = 2, width = 21, height = 23, },
	['slider-mass_btn_up'] = {left = 6, top = 2, width = 17, height = 23, },
	['slider-mass_btn_dis'] = {left = 9, top = 5, width = 11, height = 17, },
	['slider-energy_btn_down'] = {left = 0, top = 0, width = 28, height = 28, },
	['slider-energy_btn_over'] = {left = 4, top = 2, width = 21, height = 23, },
	['slider-energy_btn_up'] = {left = 6, top = 2, width = 17, height = 23, },
	['slider-energy_btn_dis'] = {left = 9, top = 5, width = 11, height = 17, },
	['slider_btn_down'] = {left = 0, top = 0, width = 28, height = 28, },
	['slider_btn_over'] = {left = 0, top = 1, width = 28, height = 25, },
	['slider_btn_up'] = {left = 0, top = 2, width = 28, height = 23, },
	['slider_btn_dis'] = {left = 0, top = 2, width = 28, height = 23, },
}

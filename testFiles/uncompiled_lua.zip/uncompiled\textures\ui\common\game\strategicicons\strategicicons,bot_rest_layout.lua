layout = {
	['icon_bot_artillery_rest'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_bot_antiair_rest'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_bot_intel_rest'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_bot_engineer_rest'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_bot_directfire_rest'] = {left = 8, top = 11, width = 16, height = 12, },
	['icon_bot_generic_rest'] = {left = 8, top = 11, width = 16, height = 12, },
}

layout = {
	['standard_btn_down'] = {left = 3, top = 4, width = 108, height = 41, },
	['standard_btn_over'] = {left = 3, top = 4, width = 108, height = 41, },
	['standard_btn_up'] = {left = 3, top = 4, width = 108, height = 41, },
	['standard_btn_dis'] = {left = 3, top = 4, width = 108, height = 41, },
}

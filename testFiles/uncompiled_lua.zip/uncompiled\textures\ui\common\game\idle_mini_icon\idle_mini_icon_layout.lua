layout = {
	['idle_icon'] = {left = 4, top = 5, width = 28, height = 24, leftOffset = 1, topOffset = 1, },
}

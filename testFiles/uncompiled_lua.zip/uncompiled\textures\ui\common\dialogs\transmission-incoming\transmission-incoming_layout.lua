layout = {
	['l_text'] = {left = 152, top = 43, width = 341, height = 83, },
	['l_close_btn'] = {left = 505, top = 18, width = 17, height = 15, },
	['l_video'] = {left = 15, top = 25, width = 108, height = 104, },
	['panel_bmp_b'] = {left = 130, top = 120, width = 404, height = 24, },
	['panel_bmp_m'] = {left = 130, top = 48, width = 404, height = 20, },
	['panel_bmp_t'] = {left = 130, top = 8, width = 404, height = 40, },
	['panel_bmp_l'] = {left = 2, top = 7, width = 136, height = 136, },
}

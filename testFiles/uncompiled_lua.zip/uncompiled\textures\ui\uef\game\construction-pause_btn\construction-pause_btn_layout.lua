layout = {
	['pause_btn_down'] = {left = 4, top = 0, width = 27, height = 28, },
	['pause_btn_over'] = {left = 4, top = 0, width = 27, height = 28, },
	['pause_btn_up'] = {left = 4, top = 0, width = 27, height = 30, },
	['pause_btn_dis'] = {left = 4, top = 0, width = 27, height = 28, },
}

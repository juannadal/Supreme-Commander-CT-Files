layout = {
	['tab-dock-l_btn_down'] = {left = 1, top = 4, width = 19, height = 40, },
	['tab-dock-l_btn_over'] = {left = 1, top = 4, width = 19, height = 40, },
	['tab-dock-l_btn_up'] = {left = 1, top = 4, width = 19, height = 40, },
	['tab-dock-l_btn_dis'] = {left = 1, top = 4, width = 19, height = 40, },
	['tab-dock-r_btn_down'] = {left = 5, top = 4, width = 19, height = 40, },
	['tab-dock-r_btn_over'] = {left = 5, top = 4, width = 19, height = 40, },
	['tab-dock-r_btn_up'] = {left = 4, top = 4, width = 20, height = 40, },
	['tab-dock-r_btn_dis'] = {left = 5, top = 4, width = 19, height = 40, },
}

layout = {
	['icon_bomber_antinavy_rest'] = {left = 7, top = 10, width = 20, height = 12, },
	['icon_bomber_directfire_rest'] = {left = 7, top = 10, width = 20, height = 12, },
	['icon_bomber_generic_rest'] = {left = 7, top = 10, width = 20, height = 12, },
}

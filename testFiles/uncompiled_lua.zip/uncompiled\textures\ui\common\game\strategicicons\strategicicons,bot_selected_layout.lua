layout = {
	['icon_bot_artillery_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_bot_antiair_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_bot_intel_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_bot_engineer_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_bot_directfire_selected'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_bot_generic_selected'] = {left = 6, top = 9, width = 20, height = 16, },
}

layout = {
	['panel-campaign_brd_lr'] = {left = 349, top = 116, width = 4, height = 4, leftOffset = 0, topOffset = 0, },
	['panel-campaign_brd_lm'] = {left = 29, top = 119, width = 4, height = 4, leftOffset = 0, topOffset = 1, },
	['panel-campaign_brd_ll'] = {left = 25, top = 116, width = 4, height = 4, leftOffset = 0, topOffset = 0, },
	['panel-campaign_brd_vert_r'] = {left = 352, top = 31, width = 4, height = 4, leftOffset = 1, topOffset = 0, },
	['panel-campaign_brd_vert_l'] = {left = 25, top = 31, width = 4, height = 4, leftOffset = 1, topOffset = 0, },
	['panel-campaign_brd_ur'] = {left = 349, top = 27, width = 4, height = 4, leftOffset = 0, topOffset = 0, },
	['panel-campaign_brd_um'] = {left = 29, top = 27, width = 4, height = 4, leftOffset = 0, topOffset = 1, },
	['panel-campaign_brd_ul'] = {left = 25, top = 27, width = 4, height = 4, leftOffset = 0, topOffset = 0, },
}

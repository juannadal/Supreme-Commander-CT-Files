layout = {
	['icon_land_antishield_selected'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_bomb_selected'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_antiair_selected'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_artillery_selected'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_counterintel_selected'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_directfire_selected'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_engineer_selected'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_missile_selected'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_shield_selected'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_intel_selected'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_generic_selected'] = {left = 7, top = 7, width = 20, height = 20, },
}

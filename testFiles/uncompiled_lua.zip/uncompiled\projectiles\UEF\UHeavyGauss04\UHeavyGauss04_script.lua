-----------------------------------------------------------------------------
--  File     :  /projectiles/uef/uheavygauss04/uheavygauss04_script.lua
--  Author(s):
--  Summary  :  SC2 UEF Heavy Gauss: UHeavyGauss04
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
local Projectile = import('/lua/sim/Projectile.lua').Projectile

UHeavyGauss04 = Class(Projectile) {
}
TypeClass = UHeavyGauss04

-----------------------------------------------------------------------------
--  File     :  /projectiles/uef/ugauss06/ugauss06_script.lua
--  Author(s):
--  Summary  :  SC2 UEF Gauss: UGauss06
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
local Projectile = import('/lua/sim/Projectile.lua').Projectile

UGauss06 = Class(Projectile) {
}
TypeClass = UGauss06

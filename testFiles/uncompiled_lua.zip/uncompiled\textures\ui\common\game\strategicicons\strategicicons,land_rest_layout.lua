layout = {
	['icon_land_antishield_rest'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_bomb_rest'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_antiair_rest'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_artillery_rest'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_counterintel_rest'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_directfire_rest'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_engineer_rest'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_missile_rest'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_shield_rest'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_intel_rest'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_generic_rest'] = {left = 9, top = 9, width = 16, height = 16, },
}

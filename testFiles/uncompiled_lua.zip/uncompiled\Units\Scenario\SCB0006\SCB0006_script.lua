-----------------------------------------------------------------------------
--  File     :  /units/scenario/scb0006/scb0006_script.lua
--  Author(s):	Chris Daroza
--  Summary  :  SC2 Illuminate Warehouse 03: SCB0006
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

local StructureUnit = import('/lua/sim/StructureUnit.lua').StructureUnit

SCB0006 = Class(StructureUnit) {
}
TypeClass = SCB0006
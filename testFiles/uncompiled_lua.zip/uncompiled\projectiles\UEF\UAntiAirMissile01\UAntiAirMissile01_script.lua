-----------------------------------------------------------------------------
--  File     : /projectiles/UEF/UAntiAirMissile01/UAntiAirMissile01_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 UEF Anti-Air Missile: UAntiAirMissile01
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
UAntiAirMissile01 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = UAntiAirMissile01
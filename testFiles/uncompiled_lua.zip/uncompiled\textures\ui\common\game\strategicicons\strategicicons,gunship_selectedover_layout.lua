layout = {
	['icon_gunship_antiair_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_gunship_transport_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_gunship_directfire_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_gunship_generic_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
}

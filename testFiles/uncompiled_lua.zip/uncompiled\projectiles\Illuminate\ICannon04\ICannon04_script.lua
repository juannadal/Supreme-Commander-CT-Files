-----------------------------------------------------------------------------
--  File     : /projectiles/Illuminate/ICannon04/ICannon04_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 Illuminate Sea Hunter Pod Cannon: ICannon04
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
ICannon04 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = ICannon04
layout = {
	['icon_fighter_bomb_over'] = {left = 9, top = 6, width = 16, height = 16, },
	['icon_fighter_missile_over'] = {left = 9, top = 6, width = 16, height = 16, },
	['icon_fighter_directfire_over'] = {left = 9, top = 6, width = 16, height = 16, },
	['icon_fighter_intel_over'] = {left = 9, top = 6, width = 16, height = 16, },
	['icon_fighter_antiair_over'] = {left = 9, top = 6, width = 16, height = 16, },
	['icon_fighter_generic_over'] = {left = 9, top = 6, width = 16, height = 16, },
}

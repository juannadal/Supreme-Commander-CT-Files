layout = {
	['text-edge-glow_bmp'] = {left = 3, top = 0, width = 10, height = 83, },
	['text-edge_bmp'] = {left = 3, top = 0, width = 10, height = 83, },
}

layout = {
	['icon_sub_intel_selectedover'] = {left = 7, top = 9, width = 20, height = 16, },
	['icon_sub_missile_selectedover'] = {left = 7, top = 9, width = 20, height = 16, },
	['icon_sub_antinavy_selectedover'] = {left = 7, top = 9, width = 20, height = 16, },
	['icon_sub_directfire_selectedover'] = {left = 7, top = 9, width = 20, height = 16, },
	['icon_sub_generic_selectedover'] = {left = 7, top = 9, width = 20, height = 16, },
}

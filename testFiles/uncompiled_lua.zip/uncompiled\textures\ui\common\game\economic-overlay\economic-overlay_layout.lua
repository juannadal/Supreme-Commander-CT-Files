layout = {
	['l_mass-energy-text'] = {left = 27, top = 11, width = 19, height = 26, leftOffset = 0, topOffset = 0, },
	['econ_bmp_r'] = {left = 51, top = 9, width = 12, height = 32, leftOffset = 1, topOffset = 0, },
	['econ_bmp_m'] = {left = 35, top = 9, width = 4, height = 32, leftOffset = 0, topOffset = 0, },
	['econ_bmp_l'] = {left = 6, top = 9, width = 24, height = 32, leftOffset = 0, topOffset = 0, },
}

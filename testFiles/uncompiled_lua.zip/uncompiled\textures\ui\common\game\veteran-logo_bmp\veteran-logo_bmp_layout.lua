layout = {
	['cybran-veteran_bmp'] = {left = 0, top = 0, width = 16, height = 16, leftOffset = 0, topOffset = 0, },
	['seraphim-veteran_bmp'] = {left = 0, top = 0, width = 16, height = 16, leftOffset = 0, topOffset = 0, },
	['aeon-veteran_bmp'] = {left = 0, top = 0, width = 16, height = 16, leftOffset = 0, topOffset = 0, },
	['uef-veteran_bmp'] = {left = 0, top = 0, width = 16, height = 16, leftOffset = 0, topOffset = 0, },
}

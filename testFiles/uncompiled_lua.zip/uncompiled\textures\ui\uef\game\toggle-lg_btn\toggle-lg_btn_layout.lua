layout = {
	['toggle-d_btn_down'] = {left = 1, top = 0, width = 110, height = 28, },
	['toggle-d_btn_over'] = {left = 1, top = 0, width = 110, height = 28, },
	['toggle-d_btn_up'] = {left = 1, top = 0, width = 110, height = 28, },
	['toggle-d_btn_dis'] = {left = 1, top = 0, width = 110, height = 28, },
	['toggle-s_btn_down'] = {left = 1, top = 0, width = 110, height = 28, },
	['toggle-s_btn_over'] = {left = 1, top = 0, width = 110, height = 28, },
	['toggle-s_btn_up'] = {left = 1, top = 0, width = 110, height = 28, },
	['toggle-s_btn_dis'] = {left = 1, top = 0, width = 110, height = 28, },
}

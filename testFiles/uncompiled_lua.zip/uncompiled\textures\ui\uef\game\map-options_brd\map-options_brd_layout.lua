layout = {
	['l_text'] = {left = 26, top = 38, width = 113, height = 174, leftOffset = 0, topOffset = 0, },
	['bracket_bmp'] = {left = 44, top = 3, width = 48, height = 28, leftOffset = 1, topOffset = 1, },
	['energy-bar_bmp'] = {left = 56, top = 2, width = 16, height = 28, leftOffset = 1, topOffset = 1, },
	['panel_brd_lr'] = {left = 185, top = 124, width = 24, height = 24, leftOffset = 1, topOffset = 1, },
	['panel_brd_lm'] = {left = 177, top = 124, width = 8, height = 24, leftOffset = 0, topOffset = 1, },
	['panel_brd_ll'] = {left = 11, top = 124, width = 24, height = 24, leftOffset = 1, topOffset = 1, },
	['panel_brd_vert_r'] = {left = 185, top = 62, width = 20, height = 8, leftOffset = 0, topOffset = 0, },
	['panel_brd_m'] = {left = 177, top = 62, width = 8, height = 8, leftOffset = 0, topOffset = 0, },
	['panel_brd_vert_l'] = {left = 13, top = 62, width = 20, height = 8, leftOffset = 0, topOffset = 0, },
	['panel_brd_ur'] = {left = 185, top = 19, width = 24, height = 44, leftOffset = 1, topOffset = 0, },
	['panel_brd_horz_um'] = {left = 177, top = 19, width = 8, height = 44, leftOffset = 0, topOffset = 0, },
	['panel_brd_ul'] = {left = 11, top = 19, width = 24, height = 44, leftOffset = 1, topOffset = 0, },
}

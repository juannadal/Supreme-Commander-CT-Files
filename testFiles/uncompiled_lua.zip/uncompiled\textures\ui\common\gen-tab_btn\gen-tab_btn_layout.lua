layout = {
	['gen-tab_btn_down'] = {left = 0, top = 0, width = 64, height = 32, },
	['gen-tab_btn_over'] = {left = 0, top = 0, width = 64, height = 32, },
	['gen-tab_btn_up'] = {left = 0, top = 0, width = 64, height = 32, },
	['gen-tab_btn_dis'] = {left = 0, top = 0, width = 64, height = 32, },
}

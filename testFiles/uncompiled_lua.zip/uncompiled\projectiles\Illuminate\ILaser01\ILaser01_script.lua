-----------------------------------------------------------------------------
--  File     :  /projectiles/illuminate/ilaser01/ilaser01_script.lua
--  Author(s):
--  Summary  :  SC2 Illuminate Laser: ILaser01
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

ILaser01 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = ILaser01
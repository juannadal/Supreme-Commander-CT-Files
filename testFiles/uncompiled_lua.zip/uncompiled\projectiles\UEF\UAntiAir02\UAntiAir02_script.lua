-----------------------------------------------------------------------------
--  File     :  /projectiles/uef/uantiair02/uantiair02_script.lua
--  Author(s):
--  Summary  :  SC2 UEF AntiAir: UAntiAir02
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

UAntiAir02 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = UAntiAir02
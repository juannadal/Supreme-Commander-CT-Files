layout = {
	['icon_sub_intel_selected'] = {left = 7, top = 9, width = 20, height = 16, },
	['icon_sub_missile_selected'] = {left = 7, top = 9, width = 20, height = 16, },
	['icon_sub_antinavy_selected'] = {left = 7, top = 9, width = 20, height = 16, },
	['icon_sub_directfire_selected'] = {left = 7, top = 9, width = 20, height = 16, },
	['icon_sub_generic_selected'] = {left = 7, top = 9, width = 20, height = 16, },
}

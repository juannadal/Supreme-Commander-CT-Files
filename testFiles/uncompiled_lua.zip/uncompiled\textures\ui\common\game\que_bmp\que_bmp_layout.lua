layout = {
	['l_infinity_button'] = {left = 10, top = 35, width = 35, height = 27, },
	['l_right_scroll'] = {left = 33, top = 6, width = 21, height = 22, },
	['l_left_scroll'] = {left = 2, top = 6, width = 21, height = 22, },
	['scroll-back_bmp'] = {left = 4, top = 8, width = 64, height = 32, },
	['que-02_bmp_r'] = {left = 440, top = 2, width = 80, height = 80, },
	['que-02_bmp_m'] = {left = 170, top = 2, width = 80, height = 80, },
	['que-02_bmp_l'] = {left = 1, top = 2, width = 80, height = 80, },
	['que_bmp_r'] = {left = 440, top = 0, width = 80, height = 80, },
	['que_bmp_m'] = {left = 170, top = 0, width = 80, height = 80, },
	['que_bmp_l'] = {left = 0, top = 0, width = 80, height = 80, },
}

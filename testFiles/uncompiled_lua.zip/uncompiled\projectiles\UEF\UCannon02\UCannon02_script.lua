-----------------------------------------------------------------------------
--  File     : /projectiles/UEF/UCannon02/UCannon02_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 UEF Commander Overcharge: UCannon02
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
UCannon02 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = UCannon02
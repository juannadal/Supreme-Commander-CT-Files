layout = {
	['panel-control_bmp_b'] = {left = 7, top = 127, width = 68, height = 24, },
	['panel-control_bmp_m'] = {left = 8, top = 52, width = 60, height = 4, },
	['panel-control_bmp_t'] = {left = 7, top = 5, width = 68, height = 48, },
}

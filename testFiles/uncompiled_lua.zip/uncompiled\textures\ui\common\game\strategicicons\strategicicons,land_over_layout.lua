layout = {
	['icon_land_antishield_over'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_bomb_over'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_antiair_over'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_artillery_over'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_counterintel_over'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_directfire_over'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_engineer_over'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_missile_over'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_shield_over'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_intel_over'] = {left = 9, top = 9, width = 16, height = 16, },
	['icon_land_generic_over'] = {left = 9, top = 9, width = 16, height = 16, },
}

layout = {
	['generic_brd_lr'] = {left = 56, top = 56, width = 8, height = 8, },
	['generic_brd_horz_lm'] = {left = 29, top = 56, width = 8, height = 8, },
	['generic_brd_ll'] = {left = 1, top = 56, width = 8, height = 8, },
	['generic_brd_vert_r'] = {left = 56, top = 28, width = 8, height = 8, },
	['generic_brd_m'] = {left = 29, top = 28, width = 8, height = 8, },
	['generic_brd_vert_l'] = {left = 1, top = 28, width = 8, height = 8, },
	['generic_brd_ur'] = {left = 56, top = 1, width = 8, height = 8, },
	['generic_brd_horz_um'] = {left = 29, top = 1, width = 8, height = 8, },
	['generic_brd_ul'] = {left = 1, top = 1, width = 8, height = 8, },
}   

layout = {
	['icon-shared-resources_bmp'] = {left = 9, top = 0, width = 64, height = 28, },
	['icon-allied-victory_bmp'] = {left = 0, top = 0, width = 84, height = 28, },
	['toggle-d_btn_down'] = {left = 2, top = 0, width = 78, height = 28, },
	['toggle-d_btn_over'] = {left = 2, top = 0, width = 78, height = 28, },
	['toggle-d_btn_up'] = {left = 2, top = 0, width = 78, height = 28, },
	['toggle-d_btn_dis'] = {left = 2, top = 0, width = 78, height = 28, },
	['toggle-s_btn_down'] = {left = 2, top = 0, width = 78, height = 28, },
	['toggle-s_btn_over'] = {left = 2, top = 0, width = 78, height = 28, },
	['toggle-s_btn_up'] = {left = 2, top = 0, width = 78, height = 28, },
	['toggle-s_btn_dis'] = {left = 2, top = 0, width = 78, height = 28, },
}

layout = {
	['target-area_bmp'] = {left = 0, top = 0, width = 64, height = 64, },
}

layout = {
	['tab-close_btn_down'] = {left = 1, top = 2, width = 23, height = 42, },
	['tab-close_btn_over'] = {left = 0, top = 2, width = 24, height = 42, },
	['tab-close_btn_up'] = {left = 0, top = 1, width = 24, height = 43, },
	['tab-close_btn_dis'] = {left = 0, top = 1, width = 24, height = 43, },
	['tab-open_btn_down'] = {left = 1, top = 2, width = 23, height = 42, },
	['tab-open_btn_over'] = {left = 0, top = 2, width = 24, height = 42, },
	['tab-open_btn_up'] = {left = 0, top = 1, width = 24, height = 43, },
	['tab-open_btn_dis'] = {left = 0, top = 1, width = 24, height = 43, },
}

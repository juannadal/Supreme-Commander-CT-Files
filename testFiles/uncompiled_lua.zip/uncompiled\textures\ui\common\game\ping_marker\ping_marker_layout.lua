layout = {
	['ping_marker-02'] = {left = 0, top = 0, width = 20, height = 20, },
	['ping_marker-01'] = {left = 0, top = 0, width = 20, height = 20, },
}

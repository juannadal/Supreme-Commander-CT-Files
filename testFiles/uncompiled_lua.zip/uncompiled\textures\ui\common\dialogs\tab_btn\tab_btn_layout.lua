layout = {
	['general_btn_selected'] = {left = 0, top = 0, width = 148, height = 40, },
	['general_btn_down'] = {left = 1, top = 4, width = 147, height = 36, },
	['general_btn_over'] = {left = 2, top = 5, width = 145, height = 34, },
	['general_btn_up'] = {left = 2, top = 5, width = 146, height = 35, },
	['general_btn_dis'] = {left = 2, top = 5, width = 145, height = 35, },
	['tab_btn_selected'] = {left = 0, top = 0, width = 148, height = 40, },
	['tab_btn_down'] = {left = 1, top = 7, width = 147, height = 33, },
	['tab_btn_over'] = {left = 2, top = 8, width = 145, height = 32, },
	['tab_btn_up'] = {left = 2, top = 8, width = 146, height = 32, },
	['tab_btn_dis'] = {left = 2, top = 8, width = 145, height = 32, },
}

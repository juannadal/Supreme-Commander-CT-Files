-----------------------------------------------------------------------------
--  File     :  /Units/Scenario/SCB0021/SCB0021_script.lua
--  Author(s):	Chris Daroza
--  Summary  :  SC2 Derelict Generic Building 01: SCB0021
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

local StructureUnit = import('/lua/sim/StructureUnit.lua').StructureUnit

SCB0021 = Class(StructureUnit) {
}
TypeClass = SCB0021
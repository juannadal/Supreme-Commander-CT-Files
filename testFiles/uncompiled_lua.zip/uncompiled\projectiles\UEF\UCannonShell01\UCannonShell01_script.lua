-----------------------------------------------------------------------------
--  File     : /projectiles/UEF/UCannonShell01/UCannonShell01_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 UEF Generic Cannon Shell: UCannonShell01
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
UCannonShell01 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = UCannonShell01
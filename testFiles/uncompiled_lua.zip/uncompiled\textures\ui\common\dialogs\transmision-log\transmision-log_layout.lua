layout = {
	['l_close'] = {left = 911, top = 89, width = 17, height = 15, },
	['l_close_btn'] = {left = 751, top = 495, width = 150, height = 38, },
	['l_scroll'] = {left = 878, top = 124, width = 33, height = 339, },
	['l_text'] = {left = 129, top = 133, width = 728, height = 319, },
	['panel_bmp'] = {left = 69, top = 32, width = 888, height = 532, },
}

layout = {
	['energy-bar-edge_btn_down'] = {left = 2, top = 0, width = 62, height = 82, },
	['energy-bar-edge_btn_over'] = {left = 2, top = 0, width = 62, height = 82, },
	['energy-bar-edge_btn_up'] = {left = 2, top = 0, width = 62, height = 82, },
	['energy-bar-edge_btn_dis'] = {left = 2, top = 0, width = 62, height = 82, },
	['mass-bar-edge_btn_down'] = {left = 2, top = 0, width = 58, height = 82, },
	['mass-bar-edge_btn_over'] = {left = 2, top = 0, width = 58, height = 82, },
	['mass-bar-edge_btn_up'] = {left = 2, top = 0, width = 58, height = 82, },
	['mass-bar-edge_btn_dis'] = {left = 2, top = 0, width = 58, height = 82, },
}

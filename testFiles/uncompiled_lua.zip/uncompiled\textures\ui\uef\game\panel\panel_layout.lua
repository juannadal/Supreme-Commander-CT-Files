layout = {
	['panel_brd_lr'] = {left = 219, top = 124, width = 24, height = 24, },
	['panel_brd_lm'] = {left = 32, top = 124, width = 8, height = 24, },
	['panel_brd_ll'] = {left = 9, top = 124, width = 24, height = 24, },
	['panel_brd_vert_r'] = {left = 219, top = 32, width = 24, height = 8, },
	['panel_brd_m'] = {left = 32, top = 32, width = 8, height = 8, },
	['panel_brd_vert_l'] = {left = 9, top = 32, width = 24, height = 8, },
	['panel_brd_ur'] = {left = 219, top = 9, width = 24, height = 24, },
	['panel_brd_horz_um'] = {left = 32, top = 9, width = 8, height = 24, },
	['panel_brd_ul'] = {left = 9, top = 9, width = 24, height = 24, },
}

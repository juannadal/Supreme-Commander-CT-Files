layout = {
	['icon_sub_intel_over'] = {left = 9, top = 11, width = 16, height = 12, },
	['icon_sub_missile_over'] = {left = 9, top = 11, width = 16, height = 12, },
	['icon_sub_antinavy_over'] = {left = 9, top = 11, width = 16, height = 12, },
	['icon_sub_directfire_over'] = {left = 9, top = 11, width = 16, height = 12, },
	['icon_sub_generic_over'] = {left = 9, top = 11, width = 16, height = 12, },
}

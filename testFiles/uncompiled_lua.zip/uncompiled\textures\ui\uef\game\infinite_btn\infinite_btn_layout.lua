layout = {
	['infinite_btn_down'] = {left = 4, top = 0, width = 27, height = 29, },
	['infinite_btn_over'] = {left = 4, top = 0, width = 28, height = 30, },
	['infinite_btn_up'] = {left = 4, top = 0, width = 27, height = 29, },
	['infinite_btn_dis'] = {left = 4, top = 0, width = 27, height = 29, },
}

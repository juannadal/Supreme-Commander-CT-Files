layout = {
	['mfd_glow'] = {left = 11, top = 45, width = 224, height = 224, },
	['l_mfd_left_btn_1'] = {left = 8, top = 7, width = 51, height = 39, },
	['l_mfd_left_btn_2'] = {left = 52, top = 7, width = 51, height = 39, },
	['l_mfd_left_btn_3'] = {left = 96, top = 7, width = 51, height = 39, },
	['l_mfd_left_btn_4'] = {left = 140, top = 7, width = 51, height = 39, },
	['l_mfd_left_btn_5'] = {left = 184, top = 7, width = 51, height = 39, },
	['mfd_button_bmp'] = {left = 0, top = 0, width = 244, height = 56, },
	['mfd_bmp'] = {left = 0, top = 47, width = 244, height = 220, },
}

layout = {
	['title-bar_bmp'] = {left = 34, top = 203, width = 188, height = 20, leftOffset = 0, topOffset = 0, },
	['video-brackets'] = {left = 7, top = 13, width = 244, height = 232, leftOffset = 0, topOffset = 0, },
	['video-panel'] = {left = 25, top = 25, width = 208, height = 208, leftOffset = 0, topOffset = 0, },
}

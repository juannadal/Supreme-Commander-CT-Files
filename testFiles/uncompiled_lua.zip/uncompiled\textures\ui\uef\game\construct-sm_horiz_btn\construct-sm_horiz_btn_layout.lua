layout = {
	['template_on'] = {left = 24, top = 7, width = 16, height = 19, },
	['template_off'] = {left = 24, top = 7, width = 16, height = 19, },
	['infinite_on'] = {left = 23, top = 6, width = 20, height = 22, },
	['infinite_off'] = {left = 23, top = 6, width = 20, height = 22, },
	['pause_on'] = {left = 23, top = 7, width = 18, height = 18, },
	['pause_off'] = {left = 23, top = 7, width = 18, height = 18, },
	['que_btn_selected'] = {left = 0, top = 0, width = 60, height = 28, },
	['que_btn_over'] = {left = 0, top = 0, width = 60, height = 28, },
	['que_btn_up'] = {left = 0, top = 0, width = 60, height = 28, },
	['que_btn_dis'] = {left = 1, top = 2, width = 59, height = 25, },
}

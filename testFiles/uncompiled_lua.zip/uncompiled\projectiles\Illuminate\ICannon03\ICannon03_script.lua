-----------------------------------------------------------------------------
--  File     : /projectiles/Illuminate/ICannon03/ICannon03_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 Illuminate Gunship Ground Cannon: ICannon03
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
ICannon03 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = ICannon03
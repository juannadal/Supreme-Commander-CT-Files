layout = {
	['mini-options-control-bar_bmp'] = {left = 2, top = 0, width = 283, height = 23, },
}

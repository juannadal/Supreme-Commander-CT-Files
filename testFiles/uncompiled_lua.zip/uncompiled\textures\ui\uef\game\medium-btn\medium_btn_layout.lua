layout = {
	['medium-uef_btn_glow'] = {left = 15, top = 0, width = 269, height = 72, },
	['medium-uef_btn_down'] = {left = 7, top = 8, width = 284, height = 59, },
	['medium-uef_btn_over'] = {left = 7, top = 8, width = 284, height = 59, },
	['medium-uef_btn_up'] = {left = 7, top = 8, width = 284, height = 59, },
	['medium-uef_btn_dis'] = {left = 7, top = 8, width = 284, height = 59, },
}

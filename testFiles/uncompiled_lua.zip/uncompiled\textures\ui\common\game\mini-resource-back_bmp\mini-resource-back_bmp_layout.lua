layout = {
	['center_bmp_l'] = {left = 1, top = 0, width = 156, height = 52, },
	['center_bmp_m'] = {left = 304, top = 0, width = 8, height = 52, },
	['center_bmp_r'] = {left = 468, top = 0, width = 156, height = 52, },
}

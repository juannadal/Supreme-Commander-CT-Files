layout = {
	['load-bar_bmp'] = {left = 376, top = 374, width = 264, height = 24, },
	['panel_bmp'] = {left = 304, top = 225, width = 404, height = 352, },
	['background-portal_bmp'] = {left = 0, top = 0, width = 1024, height = 768, },
}

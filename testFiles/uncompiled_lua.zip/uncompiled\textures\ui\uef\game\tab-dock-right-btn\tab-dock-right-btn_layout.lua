layout = {
	['tab-dock-l_btn_down'] = {left = 4, top = 4, width = 19, height = 40, },
	['tab-dock-l_btn_over'] = {left = 4, top = 4, width = 19, height = 40, },
	['tab-dock-l_btn_up'] = {left = 4, top = 4, width = 19, height = 40, },
	['tab-dock-l_btn_dis'] = {left = 4, top = 4, width = 19, height = 40, },
	['tab-dock-r_btn_down'] = {left = 0, top = 4, width = 19, height = 40, },
	['tab-dock-r_btn_over'] = {left = 0, top = 4, width = 19, height = 40, },
	['tab-dock-r_btn_up'] = {left = 0, top = 4, width = 23, height = 40, },
	['tab-dock-r_btn_dis'] = {left = 0, top = 4, width = 19, height = 40, },
}

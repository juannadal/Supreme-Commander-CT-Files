layout = {
	['icon_fighter_bomb_rest'] = {left = 9, top = 6, width = 16, height = 16, },
	['icon_fighter_missile_rest'] = {left = 9, top = 6, width = 16, height = 16, },
	['icon_fighter_directfire_rest'] = {left = 9, top = 6, width = 16, height = 16, },
	['icon_fighter_intel_rest'] = {left = 9, top = 6, width = 16, height = 16, },
	['icon_fighter_antiair_rest'] = {left = 9, top = 6, width = 16, height = 16, },
	['icon_fighter_generic_rest'] = {left = 9, top = 6, width = 16, height = 16, },
}

layout = {
	['glow_bmp'] = {left = 0, top = 1, width = 48, height = 47, },
}

layout = {
	['tab-close_btn_down'] = {left = 0, top = 2, width = 43, height = 30, },
	['tab-close_btn_over'] = {left = 0, top = 2, width = 43, height = 30, },
	['tab-close_btn_up'] = {left = 0, top = 2, width = 43, height = 30, },
	['tab-close_btn_dis'] = {left = 3, top = 3, width = 38, height = 29, },
	['tab-open_btn_down'] = {left = 0, top = 2, width = 43, height = 30, },
	['tab-open_btn_over'] = {left = 0, top = 0, width = 43, height = 32, },
	['tab-open_btn_up'] = {left = 0, top = 2, width = 43, height = 30, },
	['tab-open_btn_dis'] = {left = 2, top = 3, width = 39, height = 29, },
}

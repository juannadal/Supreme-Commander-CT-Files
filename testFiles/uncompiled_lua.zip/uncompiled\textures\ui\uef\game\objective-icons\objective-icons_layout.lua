layout = {
	['l_text-attack'] = {left = 18, top = 53, width = 27, height = 10, },
	['l_text-capture'] = {left = 16, top = 53, width = 32, height = 12, },
	['l_action-capture_icon'] = {left = 7, top = 49, width = 45, height = 17, },
	['l_action-attack_icon'] = {left = 7, top = 49, width = 45, height = 17, },
	['primary-ring_bmp'] = {left = 4, top = 4, width = 52, height = 48, },
	['secondary-ring_bmp'] = {left = 4, top = 4, width = 52, height = 48, },
	['l_unit-icon'] = {left = 9, top = 7, width = 42, height = 47, },
	['panel-icon_bmp'] = {left = 0, top = 0, width = 60, height = 68, },
}

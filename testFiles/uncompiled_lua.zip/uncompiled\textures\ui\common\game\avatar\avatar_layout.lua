layout = {
	['l_tab_btn'] = {left = 105, top = 26, width = 23, height = 44, },
	['health-bar'] = {left = 37, top = 98, width = 56, height = 12, },
	['health-bar-back_bmp'] = {left = 32, top = 96, width = 64, height = 16, },
	['l_numbers'] = {left = 47, top = 99, width = 33, height = 9, },
	['l_tech-level-text'] = {left = 18, top = 41, width = 13, height = 9, },
	['l_unit'] = {left = 11, top = 38, width = 81, height = 76, },
	['l_unit-icon'] = {left = 35, top = 35, width = 60, height = 66, },
	['pulse-bars_bmp'] = {left = 25, top = 25, width = 80, height = 80, },
	['tech-tab_bmp'] = {left = 12, top = 31, width = 32, height = 28, },
	['avatar_bmp'] = {left = 26, top = 28, width = 76, height = 88, },
}

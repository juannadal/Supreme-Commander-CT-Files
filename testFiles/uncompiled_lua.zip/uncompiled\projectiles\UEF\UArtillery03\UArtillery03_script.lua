-----------------------------------------------------------------------------
--  File     : /projectiles/UEF/UArtillery03/UArtillery03_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 UEF Artillery Shell: UArtillery03
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
UArtillery03 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = UArtillery03
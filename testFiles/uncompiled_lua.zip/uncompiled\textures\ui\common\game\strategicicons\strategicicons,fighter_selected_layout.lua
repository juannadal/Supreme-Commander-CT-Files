layout = {
	['icon_fighter_bomb_selected'] = {left = 7, top = 3, width = 20, height = 20, },
	['icon_fighter_missile_selected'] = {left = 7, top = 3, width = 20, height = 20, },
	['icon_fighter_directfire_selected'] = {left = 7, top = 3, width = 20, height = 20, },
	['icon_fighter_intel_selected'] = {left = 7, top = 3, width = 20, height = 20, },
	['icon_fighter_antiair_selected'] = {left = 7, top = 3, width = 20, height = 20, },
	['icon_fighter_generic_selected'] = {left = 7, top = 3, width = 20, height = 20, },
}

layout = {
	['l_continue'] = {left = 653, top = 700, width = 257, height = 56, },
	['l_replay_btn_up'] = {left = 103, top = 722, width = 199, height = 38, },
	['l_titles'] = {left = 428, top = 14, width = 164, height = 15, },
	['back_brd_lr'] = {left = 380, top = 628, width = 644, height = 140, },
	['back_brd_horz_lml'] = {left = 372, top = 686, width = 8, height = 84, },
	['back_brd_ll'] = {left = 0, top = 628, width = 372, height = 140, },
	['back_brd_ur'] = {left = 984, top = 0, width = 40, height = 120, },
	['back_brd_horz_umr'] = {left = 976, top = 0, width = 8, height = 56, },
	['back_brd_horz_um'] = {left = 48, top = 0, width = 928, height = 68, },
	['back_brd_horz_uml'] = {left = 40, top = 0, width = 8, height = 56, },
	['back_brd_ul'] = {left = 0, top = 0, width = 40, height = 120, },
	['background_bmp'] = {left = 0, top = 0, width = 1024, height = 768, },
}

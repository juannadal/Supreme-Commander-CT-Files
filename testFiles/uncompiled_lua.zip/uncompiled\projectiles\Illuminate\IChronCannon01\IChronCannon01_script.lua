-----------------------------------------------------------------------------
--  File     : /projectiles/Illuminate/IChronCannon01/IChronCannon01_script.lua
--  Author(s): Matt Vainio, Gordon Duclos
--  Summary  : Chronatron Cannon Projectile script, UIL0001
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
IChronCannon01 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = IChronCannon01
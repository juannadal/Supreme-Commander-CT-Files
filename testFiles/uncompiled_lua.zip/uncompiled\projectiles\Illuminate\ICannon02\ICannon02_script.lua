-----------------------------------------------------------------------------
--  File     : /projectiles/Illuminate/ICannon02/ICannon02_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 Illuminate Transport Ground Cannon: ICannon02
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
ICannon02 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = ICannon02
layout = {
	['live_logo_bmp'] = {left = 12, top = 2, width = 138, height = 24, },
}

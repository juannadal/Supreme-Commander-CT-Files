layout = {
	['slider-bar-orange_bmp'] = {left = 3, top = 4, width = 196, height = 16, },
	['slider-bar-green_bmp'] = {left = 3, top = 4, width = 196, height = 16, },
	['slider-back_bmp'] = {left = 0, top = 3, width = 200, height = 20, },
}

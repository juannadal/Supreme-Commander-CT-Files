layout = {
	['scan-lines_bmp'] = {left = 0, top = 0, width = 1600, height = 1200, },
	['texture-grime_bmp'] = {left = 0, top = 0, width = 1600, height = 1200, },
	['sc-logo_bmp'] = {left = 430, top = -1, width = 740, height = 144, },
}

-----------------------------------------------------------------------------
--  File     :  /projectiles/illuminate/iantiair03/iantiair01_script.lua
--  Author(s):	Aaron Lundquist
--  Summary  :  SC2 Illuminate Anti Air 03: IAntiAir03
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
IAntiAir03 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = IAntiAir03

layout = {
	['icon_bomber_antinavy_selected'] = {left = 5, top = 8, width = 24, height = 16, },
	['icon_bomber_directfire_selected'] = {left = 5, top = 8, width = 24, height = 16, },
	['icon_bomber_generic_selected'] = {left = 5, top = 8, width = 24, height = 16, },
}

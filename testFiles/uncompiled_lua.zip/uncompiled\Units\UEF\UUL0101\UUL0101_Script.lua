-----------------------------------------------------------------------------
--  File     : \Units\UEF\UUL0101\UUL0101_Script.lua
--  Author(s): Gordon Duclos, Aaron Lundquist
--  Summary  : UEF Tank!
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
local MobileUnit = import('/lua/sim/MobileUnit.lua').MobileUnit

UUL0101 = Class(MobileUnit) {
}
TypeClass = UUL0101
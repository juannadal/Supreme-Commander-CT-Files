layout = {
	['message-11'] = {left = 0, top = 0, width = 32, height = 32, },
	['message-10'] = {left = 0, top = 0, width = 32, height = 32, },
	['message-09'] = {left = 0, top = 0, width = 32, height = 32, },
	['message-08'] = {left = 0, top = 0, width = 32, height = 32, },
	['message-07'] = {left = 0, top = 1, width = 32, height = 31, },
	['message-06'] = {left = 0, top = 1, width = 32, height = 31, },
	['message-05'] = {left = 0, top = 1, width = 32, height = 31, },
	['message-04'] = {left = 0, top = 1, width = 32, height = 31, },
	['message-03'] = {left = 0, top = 1, width = 32, height = 31, },
	['message-02'] = {left = 0, top = 1, width = 32, height = 31, },
	['message-01'] = {left = 0, top = 1, width = 32, height = 31, },
}

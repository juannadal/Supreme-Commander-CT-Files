layout = {
	['l_ok_btn_up'] = {left = 235, top = 137, width = 185, height = 49, leftOffset = 0, topOffset = 0, },
	['l_reset_btn'] = {left = 43, top = 137, width = 185, height = 49, leftOffset = 0, topOffset = 0, },
	['l_text'] = {left = 59, top = 67, width = 241, height = 33, leftOffset = 0, topOffset = 0, },
	['panel_bmp_alt_b'] = {left = 20, top = 124, width = 424, height = 28, leftOffset = 1, topOffset = 1, },
	['panel_bmp_b'] = {left = 20, top = 124, width = 424, height = 76, leftOffset = 1, topOffset = 0, },
	['panel_bmp_m'] = {left = 20, top = 66, width = 424, height = 8, leftOffset = 1, topOffset = 0, },
	['panel_bmp_T'] = {left = 20, top = 41, width = 424, height = 28, leftOffset = 1, topOffset = 1, },
	['panel_bmp'] = {left = 16, top = 37, width = 432, height = 168, leftOffset = 1, topOffset = 0, },
}

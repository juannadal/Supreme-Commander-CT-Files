layout = {
	['pause_btn_down'] = {left = 1, top = 0, width = 30, height = 36, },
	['pause_btn_over'] = {left = 1, top = 0, width = 30, height = 36, },
	['pause_btn_up'] = {left = 1, top = 0, width = 30, height = 36, },
	['pause_btn_dis'] = {left = 1, top = 0, width = 30, height = 36, },
}

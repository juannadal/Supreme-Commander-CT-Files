layout = {
	['attached'] = {left = 11, top = 15, width = 28, height = 20, leftOffset = 0, topOffset = 0, },
	['shield'] = {left = 10, top = 11, width = 32, height = 28, leftOffset = 1, topOffset = 0, },
	['idle'] = {left = 0, top = 0, width = 48, height = 48, leftOffset = 0, topOffset = 0, },
}

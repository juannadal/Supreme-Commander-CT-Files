layout = {
	['back_bmp_l'] = {left = 0, top = 0, width = 72, height = 56, },
	['back_bmp_m'] = {left = 72, top = 0, width = 8, height = 56, },
	['back_bmp_r'] = {left = 320, top = 0, width = 20, height = 56, },
	['unit-construct-que-back_bmp'] = {left = 0, top = 0, width = 340, height = 56, },
}

-----------------------------------------------------------------------------
--  File     :  /Units/Scenario/SCB0023/SCB0023_script.lua
--  Author(s):	Chris Daroza
--  Summary  :  SC2 Derelict Generic Building 03: SCB0023
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

local StructureUnit = import('/lua/sim/StructureUnit.lua').StructureUnit

SCB0023 = Class(StructureUnit) {
}
TypeClass = SCB0023
-----------------------------------------------------------------------------
--  File     : /projectiles/UEF/UCannonShell04/UCannonShell05_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 UEF Cannon Shell: UCannonShell04
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
UCannonShell04 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = UCannonShell04
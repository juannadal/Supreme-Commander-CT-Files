layout = {
	['icon_ship_missile_selected'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_counterintel_selected'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_shield_selected'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_antinavy_selected'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_antiair_selected'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_air_selected'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_directfire_selected'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_intel_selected'] = {left = 7, top = 8, width = 20, height = 16, },
	['icon_ship_generic_selected'] = {left = 7, top = 8, width = 20, height = 16, },
}

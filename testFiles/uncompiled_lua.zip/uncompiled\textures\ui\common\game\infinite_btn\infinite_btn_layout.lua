layout = {
	['infinite_btn_down'] = {left = 1, top = 0, width = 30, height = 36, },
	['infinite_btn_over'] = {left = 1, top = 0, width = 31, height = 36, },
	['infinite_btn_up'] = {left = 1, top = 0, width = 30, height = 36, },
	['infinite_btn_dis'] = {left = 1, top = 0, width = 30, height = 36, },
}

layout = {
	['icon_ship_missile_rest'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_counterintel_rest'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_shield_rest'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_antinavy_rest'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_antiair_rest'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_air_rest'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_directfire_rest'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_intel_rest'] = {left = 9, top = 10, width = 16, height = 12, },
	['icon_ship_generic_rest'] = {left = 9, top = 10, width = 16, height = 12, },
}

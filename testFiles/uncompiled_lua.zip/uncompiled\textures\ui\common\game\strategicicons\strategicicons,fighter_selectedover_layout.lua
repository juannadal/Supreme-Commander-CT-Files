layout = {
	['icon_fighter_bomb_selectedover'] = {left = 7, top = 3, width = 20, height = 20, },
	['icon_fighter_missile_selectedover'] = {left = 7, top = 3, width = 20, height = 20, },
	['icon_fighter_directfire_selectedover'] = {left = 7, top = 3, width = 20, height = 20, },
	['icon_fighter_intel_selectedover'] = {left = 7, top = 3, width = 20, height = 20, },
	['icon_fighter_antiair_selectedover'] = {left = 7, top = 3, width = 20, height = 20, },
	['icon_fighter_generic_selectedover'] = {left = 7, top = 3, width = 20, height = 20, },
}

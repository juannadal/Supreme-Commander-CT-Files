layout = {
	['zoom_btn_down'] = {left = 0, top = 0, width = 24, height = 24, },
	['zoom_btn_over'] = {left = 0, top = 0, width = 24, height = 24, },
	['zoom_btn_up'] = {left = 0, top = 0, width = 24, height = 24, },
	['zoom_btn_dis'] = {left = 0, top = 0, width = 24, height = 24, },
}

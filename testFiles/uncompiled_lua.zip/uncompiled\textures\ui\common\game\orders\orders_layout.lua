layout = {
	['silo-build-nuke_btn_over_sel'] = {left = 1, top = 2, width = 46, height = 45, },
	['silo-build-nuke_btn_up_sel'] = {left = 1, top = 2, width = 46, height = 45, },
	['silo-build-nuke_btn_dis_sel'] = {left = 1, top = 2, width = 46, height = 45, },
}

-----------------------------------------------------------------------------
--  File     :  /projectiles/uef/uheavygauss03/uheavygauss03_script.lua
--  Author(s):
--  Summary  :  SC2 UEF Heavy Gauss: UHeavyGauss03
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
local Projectile = import('/lua/sim/Projectile.lua').Projectile

UHeavyGauss03 = Class(Projectile) {
}
TypeClass = UHeavyGauss03

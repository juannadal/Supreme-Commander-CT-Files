-----------------------------------------------------------------------------
--  File     :  /projectiles/illuminate/ilaser02/ilaser02_script.lua
--  Author(s):	Gordon Duclos
--  Summary  :  SC2 Illuminate Laser: ILaser02
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

ILaser02 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = ILaser02
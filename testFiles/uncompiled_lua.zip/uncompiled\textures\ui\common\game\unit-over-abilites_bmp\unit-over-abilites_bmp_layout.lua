layout = {
	['unit-over-abilities_bmp _t'] = {left = 11, top = 6, width = 404, height = 60, },
	['unit-over-abilities_bmp _m'] = {left = 11, top = 65, width = 404, height = 12, },
	['unit-over-abilities_bmp_b'] = {left = 10, top = 89, width = 412, height = 24, },
}

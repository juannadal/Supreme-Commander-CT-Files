layout = {
	['small_btn_down'] = {left = 324, top = 717, width = 152, height = 36, leftOffset = 1, topOffset = 0, },
	['small_btn_over'] = {left = 325, top = 718, width = 148, height = 36, leftOffset = 0, topOffset = 0, },
	['small_btn_up'] = {left = 325, top = 718, width = 148, height = 36, leftOffset = 0, topOffset = 0, },
	['small_btn_dis'] = {left = 325, top = 718, width = 148, height = 36, leftOffset = 0, topOffset = 0, },
}

layout = {
	['tab-close_btn_down'] = {left = 2, top = 0, width = 42, height = 23, },
	['tab-close_btn_over'] = {left = 2, top = 0, width = 42, height = 24, },
	['tab-close_btn_up'] = {left = 1, top = 0, width = 43, height = 24, },
	['tab-close_btn_dis'] = {left = 1, top = 0, width = 43, height = 24, },
	['tab-open_btn_down'] = {left = 2, top = 0, width = 42, height = 23, },
	['tab-open_btn_over'] = {left = 2, top = 0, width = 42, height = 24, },
	['tab-open_btn_up'] = {left = 1, top = 0, width = 43, height = 24, },
	['tab-open_btn_dis'] = {left = 1, top = 0, width = 43, height = 24, },
}

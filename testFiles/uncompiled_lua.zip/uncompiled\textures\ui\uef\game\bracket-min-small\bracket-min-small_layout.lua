layout = {
	['l_tab copy'] = {left = 12, top = 29, width = 12, height = 22, },
	['l_tab'] = {left = 0, top = 29, width = 12, height = 22, },
	['bracket-sm-right_bmp'] = {left = 4, top = 9, width = 20, height = 62, },
	['bracket-sm-left_bmp'] = {left = 0, top = 9, width = 20, height = 62, },
}

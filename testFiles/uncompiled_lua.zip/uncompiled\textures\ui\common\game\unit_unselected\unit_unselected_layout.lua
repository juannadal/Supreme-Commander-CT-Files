layout = {
	['l_scroll'] = {left = 29, top = 82, width = 33, height = 55, },
	['panel_bmp_r'] = {left = 324, top = 13, width = 264, height = 212, },
	['panel_bmp_m'] = {left = 312, top = 13, width = 12, height = 212, },
	['panel_bmp_l'] = {left = 10, top = 13, width = 304, height = 212, },
}

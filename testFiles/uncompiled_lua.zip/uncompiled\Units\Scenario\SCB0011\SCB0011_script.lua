-----------------------------------------------------------------------------
--  File     :  /Units/Scenario/SCB0011/SCB0011_script.lua
--  Author(s):	Chris Daroza
--  Summary  :  SC2 Generic Building 01: SCB0011
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

local StructureUnit = import('/lua/sim/StructureUnit.lua').StructureUnit

SCB0011 = Class(StructureUnit) {
}
TypeClass = SCB0011
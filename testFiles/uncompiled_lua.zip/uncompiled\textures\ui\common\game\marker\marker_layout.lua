layout = {
	['ring_red02-blur'] = {left = 0, top = 0, width = 200, height = 200, },
	['ring_red02'] = {left = 0, top = 0, width = 200, height = 200, },
	['ring_blue02-blur'] = {left = 3, top = 2, width = 197, height = 197, },
	['ring_blue02'] = {left = 0, top = 0, width = 200, height = 200, },
	['ring_yellow02-blur'] = {left = 3, top = 2, width = 197, height = 197, },
	['ring_yellow02'] = {left = 0, top = 0, width = 200, height = 200, },
}

-----------------------------------------------------------------------------
--  File     :  /units/scenario/scb0005/scb0005_script.lua
--  Author(s):	Chris Daroza
--  Summary  :  SC2 Illuminate Warehouse 02: SCB0005
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------

local StructureUnit = import('/lua/sim/StructureUnit.lua').StructureUnit

SCB0005 = Class(StructureUnit) {
}
TypeClass = SCB0005
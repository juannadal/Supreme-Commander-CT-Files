layout = {
	['l_text placeholder'] = {left = 176, top = 86, width = 163, height = 13, leftOffset = 0, topOffset = 0, },
	['energy_bmp'] = {left = 240, top = 55, width = 12, height = 24, leftOffset = 0, topOffset = 0, },
	['tracking-icon_bmp'] = {left = 149, top = 80, width = 24, height = 20, leftOffset = 0, topOffset = 0, },
	['panel-tracking_bmp_r'] = {left = 340, top = 70, width = 24, height = 44, leftOffset = 0, topOffset = 1, },
	['panel-tracking_bmp_d'] = {left = 239, top = 73, width = 12, height = 36, leftOffset = 0, topOffset = 0, },
	['panel-tracking_bmp_m'] = {left = 192, top = 73, width = 4, height = 36, leftOffset = 0, topOffset = 0, },
	['panel-tracking_bmp_l'] = {left = 127, top = 70, width = 24, height = 44, leftOffset = 0, topOffset = 1, },
}

layout = {
	['l_numbers'] = {left = 25, top = 59, width = 24, height = 7, },
	['l_unit-c-icon'] = {left = 24, top = 24, width = 26, height = 18, },
	['avatar-control-group_bmp'] = {left = 16, top = 16, width = 48, height = 36, },
	['l_unit-s-icon'] = {left = 22, top = 18, width = 32, height = 32, },
	['avatar-s-e-f_bmp'] = {left = 13, top = 9, width = 56, height = 52, },
	['l_unit-icon'] = {left = 17, top = 13, width = 43, height = 48, },
	['health-bar'] = {left = 18, top = 59, width = 40, height = 8, },
	['health-bar-back_bmp'] = {left = 12, top = 55, width = 52, height = 16, },
	['pulse-bars_bmp'] = {left = 7, top = 3, width = 64, height = 64, },
	['avatar_bmp'] = {left = 9, top = 6, width = 64, height = 68, },
}

-----------------------------------------------------------------------------
--  File     : /projectiles/Illuminate/IPullinsmash01/IPullinsmash01_proj.bp
--  Author(s): Gordon Duclos
--  Summary  : Pulinsmash utility projectile
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
IPullinsmash01 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = IPullinsmash01
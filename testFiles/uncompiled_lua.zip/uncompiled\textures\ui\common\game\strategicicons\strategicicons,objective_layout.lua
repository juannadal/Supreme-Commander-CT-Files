layout = {
	['icon_objective_secondary_rest'] = {left = 0, top = 0, width = 27, height = 27, },
	['icon_objective_secondary_selected'] = {left = 0, top = 0, width = 27, height = 27, },
	['icon_objective_secondary_selectedover'] = {left = 0, top = 0, width = 27, height = 27, },
	['icon_objective_secondary_over'] = {left = 0, top = 0, width = 27, height = 27, },
	['icon_objective_primary_rest'] = {left = 0, top = 0, width = 26, height = 26, },
	['icon_objective_primary_selected'] = {left = 0, top = 0, width = 27, height = 27, },
	['icon_objective_primary_selectedover'] = {left = 0, top = 0, width = 27, height = 27, },
	['icon_objective_primary_over'] = {left = 0, top = 0, width = 27, height = 27, },
}

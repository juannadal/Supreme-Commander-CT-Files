layout = {
	['resource_tutorial_bmp'] = {left = 47, top = 12, width = 664, height = 140, leftOffset = 0, topOffset = 1, },
}

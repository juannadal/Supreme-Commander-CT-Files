layout = {
	['move_window'] = {left = 2, top = 2, width = 28, height = 28, },
	['w_e'] = {left = 3, top = 6, width = 28, height = 20, },
	['ne_sw'] = {left = 5, top = 3, width = 24, height = 28, },
	['nw_se'] = {left = 5, top = 3, width = 24, height = 28, },
	['n_s'] = {left = 6, top = 2, width = 20, height = 28, },
}

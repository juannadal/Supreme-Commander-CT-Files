layout = {
	['icon_factory_air_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_factory_land_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_factory_naval_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
	['icon_factory_generic_selectedover'] = {left = 6, top = 9, width = 20, height = 16, },
}

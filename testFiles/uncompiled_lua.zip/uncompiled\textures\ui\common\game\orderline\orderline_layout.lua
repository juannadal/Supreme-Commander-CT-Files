layout = {
	['orderline_generic'] = {left = 0, top = 0, width = 64, height = 64, },
	['orderline_patrol-ferry'] = {left = 3, top = 11, width = 60, height = 40, },
	['orderline_teleport'] = {left = 0, top = 8, width = 64, height = 48, },
	['orderline_standard'] = {left = 5, top = 0, width = 60, height = 64, },
	['orderline'] = {left = 0, top = 0, width = 64, height = 64, },
}

layout = {
	['l_icons'] = {left = 81, top = 40, width = 126, height = 126, },
	['l_scroll'] = {left = 21, top = 67, width = 33, height = 55, },
	['panel_bmp_t'] = {left = 4, top = 1, width = 236, height = 128, },
	['panel_bmp_m'] = {left = 4, top = 128, width = 236, height = 8, },
	['panel_bmp_b'] = {left = 4, top = 136, width = 236, height = 76, },
}

layout = {
	['panel-icon-ring_bmp'] = {left = 1, top = 0, width = 57, height = 56, },
	['l_unit-icon'] = {left = 9, top = 8, width = 41, height = 46, },
	['panel-icon_bmp'] = {left = 1, top = 0, width = 57, height = 56, },
}

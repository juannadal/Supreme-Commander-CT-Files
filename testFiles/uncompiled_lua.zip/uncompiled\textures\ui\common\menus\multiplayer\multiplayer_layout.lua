layout = {
	['l_direct_btn_up  '] = {left = 322, top = 434, width = 380, height = 76, },
	['l_lan_btn_up '] = {left = 323, top = 331, width = 380, height = 76, },
	['l_online_btn_up'] = {left = 322, top = 225, width = 380, height = 76, },
	['panel_bmp'] = {left = 270, top = 151, width = 484, height = 460, },
	['l_main_menu_text'] = {left = 369, top = 5, width = 292, height = 36, },
	['l_exit_btn_up'] = {left = 438, top = 726, width = 152, height = 40, },
	['l_border_bmp'] = {left = 0, top = 0, width = 1024, height = 768, },
}

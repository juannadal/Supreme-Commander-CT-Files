-----------------------------------------------------------------------------
--  File     : /projectiles/illuminate/iantiair04/iantiair04_script.lua
--  Author(s): Gordon Duclos
--  Summary  : SC2 Illuminate AntiAir: IAntiAir04
--  Copyright � 2009 Gas Powered Games, Inc.  All rights reserved.
-----------------------------------------------------------------------------
IAntiAir04 = Class(import('/lua/sim/Projectile.lua').Projectile) {
}
TypeClass = IAntiAir04
layout = {
	['icon_land_antishield_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_bomb_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_antiair_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_artillery_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_counterintel_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_directfire_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_engineer_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_missile_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_shield_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_intel_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
	['icon_land_generic_selectedover'] = {left = 7, top = 7, width = 20, height = 20, },
}

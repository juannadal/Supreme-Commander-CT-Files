layout = {
	['arrow-right_scr_down'] = {left = 6, top = 0, width = 56, height = 64, },
	['arrow-right_scr_over'] = {left = 6, top = 0, width = 56, height = 64, },
	['arrow-right_scr_up'] = {left = 15, top = 3, width = 36, height = 60, },
	['arrow-right_scr_dis'] = {left = 15, top = 3, width = 36, height = 60, },
	['arrow-left_scr_down'] = {left = 6, top = 0, width = 52, height = 64, },
	['arrow-left_scr_over'] = {left = 6, top = 0, width = 52, height = 64, },
	['arrow-left_scr_up'] = {left = 14, top = 3, width = 36, height = 60, },
	['arrow-left_scr_dis'] = {left = 14, top = 3, width = 36, height = 60, },
}

layout = {
	['l_arrow'] = {left = 251, top = 33, width = 12, height = 22, leftOffset = 0, topOffset = 0, },
	['l_score-text'] = {left = 36, top = 30, width = 13, height = 109, leftOffset = 0, topOffset = 0, },
	['icon-square_bmp'] = {left = 28, top = 26, width = 24, height = 24, leftOffset = 1, topOffset = 1, },
	['panel-score_bmp_t'] = {left = 21, top = 9, width = 236, height = 44, leftOffset = 1, topOffset = 0, },
	['panel-score_bmp_m'] = {left = 21, top = 52, width = 236, height = 4, leftOffset = 1, topOffset = 0, },
	['panel-score_bmp_b'] = {left = 21, top = 128, width = 236, height = 20, leftOffset = 1, topOffset = 1, },
}

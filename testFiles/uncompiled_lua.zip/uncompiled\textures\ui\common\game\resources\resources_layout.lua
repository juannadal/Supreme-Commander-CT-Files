layout = {
	['l_option_btn_5'] = {left = 219, top = 8, width = 48, height = 44, },
	['l_option_btn_4'] = {left = 167, top = 8, width = 48, height = 44, },
	['l_option_btn_3'] = {left = 116, top = 8, width = 48, height = 44, },
	['l_option_btn_2'] = {left = 61, top = 8, width = 48, height = 44, },
	['l_option_btn_1'] = {left = 6, top = 8, width = 48, height = 44, },
	['center_bmp_m'] = {left = 0, top = 1, width = 268, height = 44, },
}

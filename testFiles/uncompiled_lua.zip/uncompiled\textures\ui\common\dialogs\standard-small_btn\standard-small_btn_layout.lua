layout = {
	['standard-small_btn_down'] = {left = 0, top = 1, width = 96, height = 30, },
	['standard-small_btn_over'] = {left = 0, top = 1, width = 96, height = 30, },
	['standard-small_btn_up'] = {left = 0, top = 1, width = 96, height = 30, },
	['standard-small_btn_dis'] = {left = 0, top = 1, width = 96, height = 30, },
}

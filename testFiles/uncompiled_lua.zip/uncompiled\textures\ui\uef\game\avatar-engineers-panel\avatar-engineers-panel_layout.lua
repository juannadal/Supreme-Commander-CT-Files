layout = {
	['l_engineer'] = {left = 102, top = 79, width = 57, height = 39, },
	['l_factory-icons'] = {left = 39, top = 15, width = 40, height = 172, },
	['tech-3_bmp'] = {left = 13, top = 67, width = 28, height = 28, },
	['tech-2_bmp'] = {left = 13, top = 111, width = 28, height = 28, },
	['tech-1_bmp'] = {left = 13, top = 150, width = 28, height = 28, },
	['bracket_bmp'] = {left = 86, top = 76, width = 28, height = 48, },
	['panel-eng_bmp_b'] = {left = 6, top = 188, width = 88, height = 12, },
	['panel-eng_bmp_m'] = {left = 6, top = 57, width = 88, height = 44, },
	['panel-eng_bmp_t'] = {left = 6, top = 3, width = 88, height = 12, },
}

layout = {
	['l_text'] = {left = 35, top = 10, width = 80, height = 26, },
	['glow-02_bmp'] = {left = 4, top = 9, width = 36, height = 36, },
	['clock_bmp'] = {left = 6, top = 10, width = 32, height = 32, },
	['timer-panel_bmp'] = {left = 0, top = 5, width = 148, height = 44, },
}
